/* Bibliotecas utilizadas */
#include <stdio.h>
#include <conio.h>

/* Prot�tipos de fun��es */
void quadrado   (void);
int  main       ();

/* Constru��o das fun��es */
void quadrado   (void)
{
	int	num;
	printf ("\n Digite um n�mero: ");
	scanf  ("%d" , &num);
	printf ("\n O quadro de %d � %d", num, num*num);
	
}

/* Corpo do programa */
int main()
{
   printf ("\n Teste com fun��es");
   quadrado();
   getch();
   return (0);
}










