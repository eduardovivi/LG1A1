/* Bibliotecas utilizadas */
#include <stdio.h>
#include <conio.h>

/* Prot�tipos de fun��es */
void quadrado   (int coisa);

/* Constru��o das fun��es */
void quadrado   (int coisa)
{
	printf ("\n O quadro de %d � %d", coisa, coisa*coisa);	
}

/* Corpo do programa */
main()
{
   int  num; /* vari�vel local */
   printf ("\n Teste com fun��es");
   printf ("\nDigite num: "); fflush (stdin); scanf ("%i", &num);
   quadrado(num);
   getch();
}










