/* Bibliotecas utilizadas */
#include <stdio.h>
#include <conio.h>

/* Prot�tipos de fun��es */
int quadrado   (int coisa);

/* Constru��o das fun��es */
int quadrado   (int coisa)
{
	return (coisa*coisa);	
}

/* Corpo do programa */
main()
{
   int  num; /* vari�vel local */
   printf ("\n Teste com fun��es");
   printf ("\nDigite num: "); fflush (stdin); scanf ("%i", &num);
   num = quadrado(num);
   printf ("\n%i ao quadrado = %i", num, num);
   getch();
}










